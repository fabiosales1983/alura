import { Observable } from 'rxjs';
import { AbstractControl, ValidationErrors } from '@angular/forms';

export function minusculoValidator(control: AbstractControl): ValidationErrors {
  const valor = control.value as string;
  if (valor !== valor.toLocaleLowerCase()) {
    return { minusculo: true };
  } else {
    return { minusculo: false };
  }
}
