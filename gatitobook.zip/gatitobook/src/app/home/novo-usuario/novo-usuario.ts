export interface NovoUsuario {
  userName: string;
  email: string;
  fullName: string;
  password: string;
}
